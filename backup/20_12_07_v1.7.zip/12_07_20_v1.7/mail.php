<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Envoi d'un message par formulaire</title>
</head>

<body>
    <?php
    // Entêtes du message
	$headers = ""; // on vide la variable
	//$headers = "From: Webmaster Site <webmaster@laforcedelaparole.com>\n"; // ajout du champ From
	$headers = "From: paull.minguet@gmail.com <PaulM>\n";
	// $headers = $headers."MIME-Version: 1.0\n"; // ajout du champ de version MIME
	$headers = $headers."Content-type: text/html; charset=iso-8859-1\n"; // ajout du type d'encodage du corps
	$message = "message de : <b>".htmlentities($_POST["user_name"])."</b><br>";
	$message = $message."adresse mail : <b>".htmlentities($_POST["user_mail"])."</b><br>";
	$message = $message."message : <br>".nl2br($_POST["user_message"])."<br>";
	 
	// Appel à la fonction mail
	if ( mail("paull.minguet@gmail.com", "contact", $message, $headers) == TRUE )
	{
        echo '<p>Votre message a bien été envoyé.</p>';
    }
    ?>
</body>
</html>